'use client';

import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import { useState } from 'react';
import { Save, X, Trash2 } from 'lucide-react';
import { useLocalDb } from '@/components/providers/localdb-provider';
import { TaskBoard } from '@/components/kanban/TaskBoard';
import { getContrastingTextColor } from '@/lib/utils/color';
import { Select } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { toLocalInputValue, inputValueToIso } from '@/lib/utils/datetime';

export default function CalendarPage() {
  const { events, categories, subcategories, addEvent, updateEvent, removeEvent } =
    useLocalDb() as any;
  const [kanbanEventId, setKanbanEventId] = useState(null as string | null);
  const [draft, setDraft] = useState(
    null as {
      id?: string;
      title: string;
      start: string;
      end: string;
      allDay: boolean;
      categoryId?: string;
      subcategoryId?: string | null;
    } | null,
  );
  const [draftCategory, setDraftCategory] = useState('' as string);
  const [draftSub, setDraftSub] = useState(null as string | null);

  const catMap = (() => {
    const map: Record<string, { name: string; colorHex: string }> = {};
    (categories as any[]).forEach((c: any) => (map[c.id] = { name: c.name, colorHex: c.colorHex }));
    return map;
  })();

  const subsByCat = (() => {
    const map: Record<string, any[]> = {};
    (subcategories as any[]).forEach((s: any) => {
      map[s.categoryId] ||= [];
      map[s.categoryId].push(s);
    });
    return map;
  })();

  const fcEvents = (() => {
    return (events as any[]).map((e: any) => {
      const col = catMap[e.categoryId]?.colorHex || '#CBD5E1';
      const text = getContrastingTextColor(col);
      return {
        id: e.id,
        title: e.title,
        start: e.startsAt,
        end: e.endsAt,
        allDay: e.allDay,
        backgroundColor: col,
        borderColor: col,
        textColor: text,
        extendedProps: { categoryId: e.categoryId },
      } as any;
    });
  })();

  const workCategoryId = (() => {
    const found = (categories as any[]).find((c: any) => c.name === '업무');
    return found?.id;
  })();

  const kanbanEvent = kanbanEventId
    ? (events as any[]).find((e: any) => e.id === kanbanEventId)
    : null;

  return (
    <div className="card-panel p-4">
      <FullCalendar
        plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
        initialView="timeGridWeek"
        locale="ko"
        buttonText={{
          today: '오늘',
          month: '월',
          week: '주',
          day: '일',
          list: '목록',
        }}
        dayHeaderFormat={{ weekday: 'short', day: '2-digit' } as any}
        slotLabelFormat={{ hour: '2-digit', minute: '2-digit', hour12: false } as any}
        headerToolbar={{
          left: 'prev,next today',
          center: 'title',
          right: 'dayGridMonth,timeGridWeek,timeGridDay',
        }}
        height="auto"
        events={fcEvents}
        selectable
        editable
        eventResizableFromStart
        eventResize={(info: any) => {
          updateEvent(info.event.id, {
            startsAt: info.event.start?.toISOString(),
            endsAt: info.event.end?.toISOString(),
            allDay: info.event.allDay,
          } as any);
        }}
        eventDrop={(info: any) => {
          updateEvent(info.event.id, {
            startsAt: info.event.start?.toISOString(),
            endsAt: info.event.end?.toISOString(),
            allDay: info.event.allDay,
          } as any);
        }}
        select={(info: any) => {
          const initialCat = workCategoryId || (categories as any[])[0]?.id;
          setDraft({
            title: '',
            start: info.startStr,
            end: info.endStr,
            allDay: info.allDay,
            categoryId: initialCat,
            subcategoryId: null,
          });
          setDraftCategory(initialCat);
          setDraftSub(null);
        }}
        eventClick={(arg: any) => {
          const e = (events as any[]).find((x: any) => x.id === arg.event.id);
          if (!e) return;
          if (workCategoryId && e.categoryId === workCategoryId) {
            setKanbanEventId(e.id);
            return;
          }
          setDraft({
            id: e.id,
            title: e.title,
            start: e.startsAt,
            end: e.endsAt,
            allDay: e.allDay,
            categoryId: e.categoryId,
            subcategoryId: e.subcategoryId ?? null,
          });
          setDraftCategory(e.categoryId);
          setDraftSub(e.subcategoryId ?? null);
        }}
      />

      {draft && (
        <div
          className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm"
          onClick={() => setDraft(null)}
        >
          <div
            className="absolute left-1/2 top-20 w-[min(680px,94vw)] -translate-x-1/2 overflow-hidden rounded-2xl border border-slate-200 bg-white/90 shadow-xl"
            onClick={(e: any) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b px-5 py-3">
              <h3 className="text-base font-semibold">{draft.id ? '일정 수정' : '일정 추가'}</h3>
              <button
                className="rounded-md p-1 text-slate-600 hover:bg-slate-100"
                onClick={() => setDraft(null)}
              >
                <X size={18} />
              </button>
            </div>
            <div className="px-5 py-4 space-y-4">
              <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                <div>
                  <div className="mb-1 text-xs font-medium text-slate-600">제목</div>
                  <Input
                    placeholder="제목"
                    value={draft.title}
                    onChange={(e) => setDraft({ ...draft, title: e.target.value })}
                  />
                </div>
                <div>
                  <div className="mb-1 text-xs font-medium text-slate-600">카테고리</div>
                  <Select
                    value={draftCategory}
                    onChange={(e) => {
                      setDraftCategory(e.target.value);
                      setDraftSub(null);
                    }}
                  >
                    {(categories as any[]).map((c: any) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                <div>
                  <div className="mb-1 text-xs font-medium text-slate-600">하위 카테고리</div>
                  <Select
                    value={draftSub ?? ''}
                    onChange={(e) => setDraftSub(e.target.value || null)}
                  >
                    <option value="">선택 안 함</option>
                    {(subsByCat[draftCategory] || []).map((s: any) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </Select>
                </div>
                <div className="flex items-center gap-2 pt-6">
                  <input
                    id="allDay"
                    type="checkbox"
                    className="h-4 w-4 rounded border-slate-300"
                    checked={draft.allDay}
                    onChange={(e) => setDraft({ ...draft, allDay: e.target.checked })}
                  />
                  <label htmlFor="allDay" className="text-sm text-slate-700">
                    종일
                  </label>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                <div>
                  <div className="mb-1 text-xs font-medium text-slate-600">시작</div>
                  <input
                    type="datetime-local"
                    className="h-10 w-full rounded-md border border-slate-200 bg-white/70 px-3 text-sm shadow-sm outline-none focus:ring-2 focus:ring-primary/30"
                    value={toLocalInputValue(draft.start)}
                    onChange={(e) => setDraft({ ...draft, start: inputValueToIso(e.target.value) })}
                  />
                </div>
                <div>
                  <div className="mb-1 text-xs font-medium text-slate-600">종료</div>
                  <input
                    type="datetime-local"
                    className="h-10 w-full rounded-md border border-slate-200 bg-white/70 px-3 text-sm shadow-sm outline-none focus:ring-2 focus:ring-primary/30"
                    value={toLocalInputValue(draft.end)}
                    onChange={(e) => setDraft({ ...draft, end: inputValueToIso(e.target.value) })}
                  />
                </div>
              </div>
            </div>
            <div className="flex items-center justify-between border-t px-5 py-3">
              {draft.id ? (
                <Button
                  className="bg-red-500 hover:opacity-95 inline-flex items-center gap-1"
                  onClick={() => {
                    if (confirm('정말 삭제하시겠어요?')) {
                      removeEvent(draft.id as string);
                      setDraft(null);
                    }
                  }}
                >
                  <Trash2 size={16} /> 삭제
                </Button>
              ) : (
                <div />
              )}
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  className="inline-flex items-center gap-1 text-slate-800"
                  onClick={() => setDraft(null)}
                >
                  <X size={16} /> 취소
                </Button>
                <Button
                  className="inline-flex items-center gap-1"
                  onClick={() => {
                    if (!draft.title) return;
                    if (draft.id) {
                      updateEvent(draft.id, {
                        title: draft.title,
                        categoryId: draftCategory,
                        subcategoryId: draftSub,
                        startsAt: draft.start,
                        endsAt: draft.end,
                        allDay: draft.allDay,
                      } as any);
                      setDraft(null);
                    } else {
                      addEvent({
                        title: draft.title,
                        description: '',
                        categoryId: draftCategory,
                        subcategoryId: draftSub,
                        startsAt: draft.start,
                        endsAt: draft.end,
                        allDay: draft.allDay,
                        location: '',
                      } as any);
                      setDraft(null);
                    }
                  }}
                >
                  <Save size={16} /> 저장
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {kanbanEventId && (
        <div className="fixed inset-0 z-50 bg-black/30" onClick={() => setKanbanEventId(null)}>
          <div
            className="absolute right-0 top-0 h-full w-full max-w-2xl lg:max-w-3xl bg-white p-4"
            onClick={(e: any) => e.stopPropagation()}
          >
            <div className="mb-3 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <h3 className="text-lg font-semibold">업무 보드</h3>
                {kanbanEvent ? (
                  <span className="rounded bg-slate-100 px-2 py-0.5 text-xs text-slate-700">
                    {kanbanEvent.title}
                  </span>
                ) : null}
              </div>
              <div className="flex items-center gap-2">
                {kanbanEventId ? (
                  <button
                    className="rounded bg-red-500 px-3 py-1 text-xs font-medium text-white"
                    onClick={() => {
                      if (confirm('해당 업무 일정을 삭제할까요? 관련 Task도 함께 정리됩니다.')) {
                        removeEvent(kanbanEventId as string);
                        setKanbanEventId(null);
                      }
                    }}
                  >
                    일정 삭제
                  </button>
                ) : null}
                <button className="text-sm" onClick={() => setKanbanEventId(null)}>
                  닫기
                </button>
              </div>
            </div>
            <TaskBoard eventId={kanbanEventId} />
          </div>
        </div>
      )}
    </div>
  );
}
