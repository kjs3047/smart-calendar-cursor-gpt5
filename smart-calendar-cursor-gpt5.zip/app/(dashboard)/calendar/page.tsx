'use client';

import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import { useState } from 'react';
import { useLocalDb } from '@/components/providers/localdb-provider';
import { TaskBoard } from '@/components/kanban/TaskBoard';
import { getContrastingTextColor } from '@/lib/utils/color';
import { Select } from '@/components/ui/select';
import { Button } from '@/components/ui/button';

export default function CalendarPage() {
  const { events, categories, subcategories, addEvent, updateEvent, removeEvent } =
    useLocalDb() as any;
  const [kanbanEventId, setKanbanEventId] = useState(null as string | null);
  const [draft, setDraft] = useState(
    null as {
      id?: string;
      title: string;
      start: string;
      end: string;
      allDay: boolean;
      categoryId?: string;
      subcategoryId?: string | null;
    } | null,
  );
  const [draftCategory, setDraftCategory] = useState('' as string);
  const [draftSub, setDraftSub] = useState(null as string | null);

  const catMap = (() => {
    const map: Record<string, { name: string; colorHex: string }> = {};
    (categories as any[]).forEach((c: any) => (map[c.id] = { name: c.name, colorHex: c.colorHex }));
    return map;
  })();

  const subsByCat = (() => {
    const map: Record<string, any[]> = {};
    (subcategories as any[]).forEach((s: any) => {
      map[s.categoryId] ||= [];
      map[s.categoryId].push(s);
    });
    return map;
  })();

  const fcEvents = (() => {
    return (events as any[]).map((e: any) => {
      const col = catMap[e.categoryId]?.colorHex || '#CBD5E1';
      const text = getContrastingTextColor(col);
      return {
        id: e.id,
        title: e.title,
        start: e.startsAt,
        end: e.endsAt,
        allDay: e.allDay,
        backgroundColor: col,
        borderColor: col,
        textColor: text,
        extendedProps: { categoryId: e.categoryId },
      } as any;
    });
  })();

  const workCategoryId = (() => {
    const found = (categories as any[]).find((c: any) => c.name === '업무');
    return found?.id;
  })();

  const kanbanEvent = kanbanEventId
    ? (events as any[]).find((e: any) => e.id === kanbanEventId)
    : null;

  return (
    <div className="card-panel p-4">
      <FullCalendar
        plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
        initialView="timeGridWeek"
        headerToolbar={{
          left: 'prev,next today',
          center: 'title',
          right: 'dayGridMonth,timeGridWeek,timeGridDay',
        }}
        height="auto"
        events={fcEvents}
        selectable
        editable
        eventResizableFromStart
        eventResize={(info: any) => {
          updateEvent(info.event.id, {
            startsAt: info.event.start?.toISOString(),
            endsAt: info.event.end?.toISOString(),
            allDay: info.event.allDay,
          } as any);
        }}
        eventDrop={(info: any) => {
          updateEvent(info.event.id, {
            startsAt: info.event.start?.toISOString(),
            endsAt: info.event.end?.toISOString(),
            allDay: info.event.allDay,
          } as any);
        }}
        select={(info: any) => {
          const initialCat = workCategoryId || (categories as any[])[0]?.id;
          setDraft({
            title: '',
            start: info.startStr,
            end: info.endStr,
            allDay: info.allDay,
            categoryId: initialCat,
            subcategoryId: null,
          });
          setDraftCategory(initialCat);
          setDraftSub(null);
        }}
        eventClick={(arg: any) => {
          const e = (events as any[]).find((x: any) => x.id === arg.event.id);
          if (!e) return;
          if (workCategoryId && e.categoryId === workCategoryId) {
            setKanbanEventId(e.id);
            return;
          }
          setDraft({
            id: e.id,
            title: e.title,
            start: e.startsAt,
            end: e.endsAt,
            allDay: e.allDay,
            categoryId: e.categoryId,
            subcategoryId: e.subcategoryId ?? null,
          });
          setDraftCategory(e.categoryId);
          setDraftSub(e.subcategoryId ?? null);
        }}
      />

      {draft && (
        <div className="fixed inset-0 z-50 bg-black/40" onClick={() => setDraft(null)}>
          <div
            className="absolute left-1/2 top-24 w-[min(560px,92vw)] -translate-x-1/2 rounded-2xl bg-white p-5 shadow-lg"
            onClick={(e: any) => e.stopPropagation()}
          >
            <h3 className="mb-4 text-lg font-semibold">{draft.id ? '일정 수정' : '일정 추가'}</h3>
            <div className="mb-3 grid grid-cols-1 gap-3 md:grid-cols-2">
              <input
                className="h-10 w-full rounded-lg border bg-white/60 px-3 text-sm shadow-sm outline-none focus:ring-2 focus:ring-primary/30"
                placeholder="제목"
                value={draft.title}
                onChange={(e) => setDraft({ ...draft, title: e.target.value })}
              />
              <Select
                value={draftCategory}
                onChange={(e) => {
                  setDraftCategory(e.target.value);
                  setDraftSub(null);
                }}
              >
                {(categories as any[]).map((c: any) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </Select>
            </div>
            <div className="mb-4 grid grid-cols-1 gap-3 md:grid-cols-2">
              <Select value={draftSub ?? ''} onChange={(e) => setDraftSub(e.target.value || null)}>
                <option value="">하위 카테고리(선택)</option>
                {(subsByCat[draftCategory] || []).map((s: any) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </Select>
              <div />
            </div>
            <div className="flex items-center justify-between gap-2">
              {draft.id ? (
                <Button
                  className="bg-red-500 hover:opacity-95"
                  onClick={() => {
                    if (confirm('정말 삭제하시겠어요?')) {
                      removeEvent(draft.id as string);
                      setDraft(null);
                    }
                  }}
                >
                  삭제
                </Button>
              ) : (
                <div />
              )}
              <div className="flex gap-2">
                <Button className="bg-slate-200 text-slate-800" onClick={() => setDraft(null)}>
                  취소
                </Button>
                <Button
                  onClick={() => {
                    if (!draft.title) return;
                    if (draft.id) {
                      updateEvent(draft.id, {
                        title: draft.title,
                        categoryId: draftCategory,
                        subcategoryId: draftSub,
                        startsAt: draft.start,
                        endsAt: draft.end,
                        allDay: draft.allDay,
                      } as any);
                      setDraft(null);
                    } else {
                      addEvent({
                        title: draft.title,
                        description: '',
                        categoryId: draftCategory,
                        subcategoryId: draftSub,
                        startsAt: draft.start,
                        endsAt: draft.end,
                        allDay: draft.allDay,
                        location: '',
                      } as any);
                      setDraft(null);
                    }
                  }}
                >
                  저장
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {kanbanEventId && (
        <div className="fixed inset-0 z-50 bg-black/30" onClick={() => setKanbanEventId(null)}>
          <div
            className="absolute right-0 top-0 h-full w-full max-w-2xl lg:max-w-3xl bg-white p-4"
            onClick={(e: any) => e.stopPropagation()}
          >
            <div className="mb-3 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <h3 className="text-lg font-semibold">업무 보드</h3>
                {kanbanEvent ? (
                  <span className="rounded bg-slate-100 px-2 py-0.5 text-xs text-slate-700">
                    {kanbanEvent.title}
                  </span>
                ) : null}
              </div>
              <div className="flex items-center gap-2">
                {kanbanEventId ? (
                  <button
                    className="rounded bg-red-500 px-3 py-1 text-xs font-medium text-white"
                    onClick={() => {
                      if (confirm('해당 업무 일정을 삭제할까요? 관련 Task도 함께 정리됩니다.')) {
                        removeEvent(kanbanEventId as string);
                        setKanbanEventId(null);
                      }
                    }}
                  >
                    일정 삭제
                  </button>
                ) : null}
                <button className="text-sm" onClick={() => setKanbanEventId(null)}>
                  닫기
                </button>
              </div>
            </div>
            <TaskBoard eventId={kanbanEventId} />
          </div>
        </div>
      )}
    </div>
  );
}
