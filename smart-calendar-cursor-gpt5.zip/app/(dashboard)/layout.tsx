import React from 'react';
import Link from 'next/link';
import { LocalSignOutButton } from '@/components/auth/local-auth-buttons';

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="grid grid-cols-1 gap-6">
      <header className="flex items-center justify-between rounded-md border bg-white p-4">
        <div className="flex items-center gap-4">
          <Link href="/calendar" className="font-semibold">
            캘린더
          </Link>
          <Link href="/tasks" className="font-semibold">
            업무
          </Link>
          <Link href="/admin/categories" className="font-semibold">
            관리자
          </Link>
        </div>
        <LocalSignOutButton />
      </header>
      <main>{children}</main>
    </div>
  );
}
