'use client';

import { useLocalDb } from '@/components/providers/localdb-provider';
import { useMemo, useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

export default function AdminCategoriesPage() {
  const {
    categories,
    subcategories,
    addCategory,
    addSubcategory,
    updateCategory,
    updateSubcategory,
    deleteCategory,
    deleteSubcategory,
    events,
  } = useLocalDb() as any;
  const [name, setName] = useState('');
  const [color, setColor] = useState('#7C3AED');
  const [parentId, setParentId] = useState('');
  const [subName, setSubName] = useState('');

  const sortedCats = useMemo(
    () => [...categories].sort((a, b) => a.sortOrder - b.sortOrder),
    [categories],
  );

  const usageCount = (catId: string) => events.filter((e: any) => e.categoryId === catId).length;

  return (
    <div className="card-panel p-4">
      <h2 className="mb-2 text-xl font-semibold">카테고리 관리</h2>
      <div className="mb-6 grid grid-cols-1 gap-2 md:grid-cols-5">
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="카테고리명" />
        <input
          type="color"
          value={color}
          onChange={(e) => setColor(e.target.value)}
          className="h-10 w-full rounded-lg border"
        />
        <Button
          onClick={() => {
            if (!name) return;
            addCategory({ name, colorHex: color, isActive: true, sortOrder: categories.length });
            setName('');
          }}
        >
          추가
        </Button>
      </div>

      <div className="mb-6 grid grid-cols-1 gap-2 md:grid-cols-5">
        <select
          value={parentId}
          onChange={(e) => setParentId(e.target.value)}
          className="h-10 w-full rounded-lg border bg-white/60 px-3 text-sm shadow-sm outline-none focus:ring-2 focus:ring-primary/30"
        >
          <option value="">상위 카테고리 선택</option>
          {sortedCats.map((c: any) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
        <Input
          value={subName}
          onChange={(e) => setSubName(e.target.value)}
          placeholder="하위 카테고리명"
        />
        <Button
          className="bg-secondary"
          onClick={() => {
            if (!parentId || !subName) return;
            addSubcategory({
              categoryId: parentId,
              name: subName,
              colorHex: null,
              isActive: true,
              sortOrder: 0,
            });
            setSubName('');
          }}
        >
          하위 추가
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        {sortedCats.map((c: any) => (
          <div key={c.id} className="rounded border p-3">
            <div className="mb-2 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span
                  className="inline-block h-4 w-4 rounded-full"
                  style={{ backgroundColor: c.colorHex }}
                />
                <input
                  className="rounded border px-2 py-1 text-sm"
                  value={c.name}
                  onChange={(e) => updateCategory(c.id, { name: e.target.value })}
                />
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <span>사용: {usageCount(c.id)}</span>
                <button
                  className="rounded bg-red-500 px-2 py-1 text-white"
                  onClick={() => {
                    const res = deleteCategory(c.id);
                    if (!res.ok) alert(res.reason);
                  }}
                >
                  삭제
                </button>
              </div>
            </div>
            <ul className="space-y-1 text-sm text-slate-700">
              {subcategories
                .filter((s: any) => s.categoryId === c.id)
                .map((s: any) => (
                  <li key={s.id} className="flex items-center justify-between gap-2">
                    <input
                      className="w-full rounded border px-2 py-1"
                      value={s.name}
                      onChange={(e) => updateSubcategory(s.id, { name: e.target.value })}
                    />
                    <button
                      className="rounded bg-slate-200 px-2 py-1"
                      onClick={() => deleteSubcategory(s.id)}
                    >
                      삭제
                    </button>
                  </li>
                ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
