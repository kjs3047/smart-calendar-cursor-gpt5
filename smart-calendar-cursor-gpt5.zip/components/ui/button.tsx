'use client';

import React from 'react';
import { cn } from '@/lib/utils/cn';

export function Button({ className, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      className={cn(
        'inline-flex items-center justify-center rounded-lg px-4 py-2 text-sm font-medium shadow-sm transition',
        'bg-primary text-white hover:opacity-90 active:opacity-100',
        className,
      )}
      {...props}
    />
  );
}
