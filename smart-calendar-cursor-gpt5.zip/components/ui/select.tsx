'use client';

import React from 'react';
import { cn } from '@/lib/utils/cn';

export function Select({ className, ...props }: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      className={cn(
        'h-10 w-full rounded-lg border bg-white/60 px-3 text-sm shadow-sm outline-none transition',
        'focus:ring-2 focus:ring-primary/30',
        className,
      )}
      {...props}
    />
  );
}
